package ru.kinopoisk.search.service;

import java.io.IOException;

public interface TopService {

    void getTop() throws IOException;

}
